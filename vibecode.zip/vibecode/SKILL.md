---
name: vibecode
description: Use the NTU Gemini Vibe Bridge to read a project's OneDrive snapshot and deliver requested changes as one verified delta upload.
---

# Vibe Code with NTU OneDrive

Select `/vibecode`, put the exact project folder name on the first line, and put the task on the following lines. For example:

```text
/vibecode RepairCafePlanner
Add a unit test for an empty schedule.
```

If the mention UI removes the skill token, read the first line after the mention as the project name. Accept a single exact folder name, with optional surrounding quotes. Ask for it if missing, ambiguous, or a path. Use that project in follow-up turns until the user chooses another.

If the user only names a project, read its snapshot and wait for a task. An explicit change request includes delivery in the same turn. Questions, reviews, and drafts are read-only.

An upload-only follow-up continues the previous change. For `/syncvibecode now` or an explicit request to upload immediately, retrieve the exact retained delta and run `validate_delta_envelope(content, project)`. If it passes, upload those same bytes with the same patch ID. Skip the snapshot and slot checks, tests, and repackaging. If the package is missing or fails the check, report the blocker and suggest plain `/syncvibecode` for verified recovery.

## Read the current snapshot and assets

Use Microsoft OneDrive to download the complete `projects/<ProjectName>/repo-context.txt` by exact path. Use a direct OneDrive lookup and download. Reuse any project folder or drive ID returned for that exact path when the upload needs it. If the exact lookup fails, report the path and connector error. Use the active skill or supplied prompt. Use only exact project paths for OneDrive lookups and load the recovery skill only for an explicit recovery request. Read the snapshot again for each change request. It is JSON with format `vibebridge-snapshot-v2`. In the Python tool, parse that exact downloaded file and use the same snapshot object to reconstruct the workspace and generate the patch. Copy the snapshot ID from the parsed object. If the user includes `VibeBridge: snapshot <ID>`, compare it with the downloaded snapshot before editing and pass that ID to `pack_delta` as `expected_snapshot_id`. If they differ, report both IDs and stop before requesting an upload. For editable text, reconstruct the original bytes with `snapshot_bytes(entry)` below. Write those bytes to an isolated workspace before editing. Keep each file's BOM, line endings, and final newline unless the task explicitly changes the final newline. If the snapshot is missing or uses the older format, ask the user to start the updated watcher.

For binary bytes, download the actual asset from `projects/<ProjectName>/assets/`. If its file type is unsupported, download the complete `asset-bytes/<path-below-assets>.base64.txt` and decode it with `base64.b64decode(text.strip(), validate=True)`. Check the byte length if the task gives an expected length. Report a missing, partial, or mismatched asset before using it.

## Deliver the change in the same turn

Keep control with the caller that has the registered Microsoft OneDrive **Upload file** action. Before editing, confirm that this same caller can run Python directly and then call **Upload file**. For a small task, run Python directly in that caller. Delegate only through a real tool that returns the complete result to this caller in the same turn. If the necessary tool path is unavailable, report the exact blocker before editing. A printed transfer marker or tool-call snippet is chat text.

1. Edit and test the isolated workspace. Run the exact Python packer below against the downloaded snapshot and the final tested files. Pass the explicit changed paths. Use its output as the patch. It emits exact `edits` for text changes and `confirmDelete: true` for authorized deletions. A `create` operation uses either a `text` string for UTF-8 or a `base64` string for exact bytes. Supply one field per operation. Replacements use `base64`.
2. Check the exact `projects/<ProjectName>/apply-changes.ps1` path once and upload only if the slot is clear. Use the exact `pack_delta()` return value and save the ASCII package as `vibebridge-<patchId>.txt` in the isolated workspace. Record the byte count. Return the complete text to the OneDrive-capable caller through tool output if needed for direct upload. If stdout is the only route, use separate boundary lines, exclude the boundaries and separator newline from the package, and compare its length to detect truncation. Run `validate_delta_envelope(content, project)` on the exact content before delivery. Keep source and payload text in tools.
3. Immediately invoke the registered Microsoft OneDrive **Upload file** action in this turn using the method below.
4. Before any final reply, either obtain the actual connector result, surface its pending confirmation, or state the exact blocker and which action could not be called. Reply with a short summary of changes, checks, destination, snapshot ID, patch ID, byte count, and upload status. Keep full source, Base64, and patch text out of the visible reply. After success, the local watcher reports `[PATCH]`, `[APPLIED]`, and a fresh `[READY]`. Wait for the new snapshot before delivering another change.

## OneDrive upload method

1. Call the registered Microsoft OneDrive **Upload file** action using direct `Content` by default. Use the exact ASCII delta returned by the packer or read from the retained file. Set `FileName` to `apply-changes.ps1`, `HasBytes` to false when available, and `InputFileName` to `apply-changes.ps1` if required. The filename is the watcher's inbox convention. The body is delta data.
2. If the user explicitly requests a file reference and the exact validated package is available as a connector-visible attachment, set `InputFileName` to its actual attachment name and leave `Content` and `ContentBytes` unset. A Python workspace filename alone is insufficient. If the reference is unavailable or explicitly fails before writing, use the exact package as direct `Content`.
3. Count an upload as requested when the real connector responds or displays its approval card. If the outcome is uncertain, report it and stop. Keep tool markup, source, and package text out of the visible reply.

## Python packer

Use the Python tool in the same caller as OneDrive. Load the bundled
scripts/pack_delta.py from the skill directory already mounted in that tool:
namespace = runpy.run_path(str(skill_directory / "scripts" / "pack_delta.py"))
Import runpy and use a pathlib.Path for skill_directory. Call namespace["snapshot_bytes"]
to reconstruct editable snapshot files when needed. Call namespace["pack_delta"]
with the downloaded snapshot, the tested workspace, and explicit edit, create,
replace, or delete path lists. Supply expected_snapshot_id when provided by the
user or when resuming a prior patch. Use delete only for user-authorized deletions.
Call namespace["validate_delta_envelope"](content, project) before upload.
For a retained file, read its exact text with Path.read_bytes().decode("ascii").
Send the original text after validation.

If the helper is unavailable to the OneDrive-capable caller, report that blocker
and ask the user to paste the standalone start prompt from PROMPT.md in a fresh chat. It includes the Python helper.
