---
name: syncvibecode
description: Finish a previously requested Vibe Bridge upload through Microsoft OneDrive. Use syncvibecode now to upload the prepared package immediately, or syncvibecode for verified recovery.
---

# Finish a Vibe Bridge upload

Use this skill in the same chat after a `/vibecode` or standalone Vibe Bridge coding turn that prepared a user-authorized change and stopped before delivery. Use the exact project and pending change from that turn. If either is ambiguous, ask for the missing information. If this chat already shows a pending confirmation or uncertain upload outcome, report its status. If the connector already succeeded, report that result unless the user says the watcher rejected it and requests verified recovery.

## Immediate upload with `/syncvibecode now`

Use this mode when the user types `now` after the skill mention. Retrieve the exact retained package from the previous change. In the OneDrive-capable caller, read its bytes as ASCII and run `validate_delta_envelope(content, project)` from the helper below. It checks the `# VibeBridge Delta v2` header and parses the JSON object with version, project, snapshot ID, patch ID, and operations. Keep the original content and patch ID. If the exact package is missing or fails the check, report the blocker and suggest plain `/syncvibecode` for verified recovery.

Skip rereading `repo-context.txt`, checking the upload slot, reconstructing files, running tests, and repackaging. Resolve the exact `projects/<ProjectName>` folder only if the connector requires an unavailable ID. Invoke the real **Upload file** action using the method below. Reply with the actual connector result, pending approval, or exact blocker.

## Verified recovery with `/syncvibecode`

Use this workflow when the user invokes the skill without `now`. Identify the original snapshot ID and requested files from the previous change. If either is ambiguous, ask for the missing information.

## Check the destination and snapshot

- Use a direct OneDrive lookup and download for `projects/<ProjectName>/repo-context.txt` by exact path. Parse it in Python. Require the project name and `snapshotId` to match the snapshot used for the tested change. If the ID has changed, report both IDs and ask the user to request a new patch against the fresh snapshot.
- Reuse the exact project folder ID if already available and check `projects/<ProjectName>/apply-changes.ps1` before uploading. If it already exists or the lookup fails for a reason other than the file being absent, report that status and stop.

## Recover and deliver the tested patch

1. Keep control with the caller that has the registered Microsoft OneDrive **Upload file** action and direct Python access. If that path is unavailable, report the blocker. Reuse the exact retained delta if it passes `validate_delta_envelope(content, project)` and matches the original snapshot and requested files. Keep its original patch ID and text.
2. If the previous package is missing or malformed, recover the previously tested file bytes in an isolated workspace. Use the direct Python tool to run the packer below on those files and pass the original ID as `expected_snapshot_id`. Include only the previous change. If the tested bytes cannot be recovered, report which artifact is missing.
3. Run `validate_delta_envelope(content, project)` before invoking the real **Upload file** action. Return the exact text from Python to the caller and compare its byte count to catch truncation. Keep the payload in tools.
4. Report the actual connector result, pending confirmation, or exact blocker. Include the destination, snapshot ID, patch ID, and size when available. Keep source, Base64, and package text out of the visible reply. Local application is confirmed by the watcher’s **[APPLIED]** and **[READY]** messages.

## OneDrive upload method

1. Call the registered Microsoft OneDrive **Upload file** action using direct `Content` by default. Use the exact ASCII delta returned by the packer or read from the retained file. Set `FileName` to `apply-changes.ps1`, `HasBytes` to false when available, and `InputFileName` to `apply-changes.ps1` if required. The filename is the watcher's inbox convention. The body is delta data.
2. If the user explicitly requests a file reference and the exact validated package is available as a connector-visible attachment, set `InputFileName` to its actual attachment name and leave `Content` and `ContentBytes` unset. A Python workspace filename alone is insufficient. If the reference is unavailable or explicitly fails before writing, use the exact package as direct `Content`.
3. Count an upload as requested when the real connector responds or displays its approval card. If the outcome is uncertain, report it and stop. Keep tool markup, source, and package text out of the visible reply.

## Python packer

Use the Python tool in the same caller as OneDrive. Load the bundled
scripts/pack_delta.py from the skill directory already mounted in that tool:
namespace = runpy.run_path(str(skill_directory / "scripts" / "pack_delta.py"))
Import runpy and use a pathlib.Path for skill_directory. Call namespace["snapshot_bytes"]
to reconstruct editable snapshot files when needed. Call namespace["pack_delta"]
with the downloaded snapshot, the tested workspace, and explicit edit, create,
replace, or delete path lists. Supply expected_snapshot_id when provided by the
user or when resuming a prior patch. Use delete only for user-authorized deletions.
Call namespace["validate_delta_envelope"](content, project) before upload.
For a retained file, read its exact text with Path.read_bytes().decode("ascii").
Send the original text after validation.

If the helper is unavailable to the OneDrive-capable caller, report that blocker
and ask the user to paste the standalone start prompt from PROMPT.md in a fresh chat. It includes the Python helper.
